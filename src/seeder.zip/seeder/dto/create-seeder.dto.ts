export class CreateSeederDto {}
