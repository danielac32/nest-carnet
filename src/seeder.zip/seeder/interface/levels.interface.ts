

export interface Levels{
	name : string;
}