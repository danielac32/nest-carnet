export class Seeder {}
