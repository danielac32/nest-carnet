export class Carnet {}
